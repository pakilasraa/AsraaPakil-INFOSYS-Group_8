package com.mycompany.deseventeencustomerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
